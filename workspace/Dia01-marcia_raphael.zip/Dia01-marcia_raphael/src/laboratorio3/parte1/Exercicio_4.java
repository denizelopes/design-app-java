package laboratorio3.parte1;

import java.util.function.BiFunction;

public class Exercicio_4 {

	public static void main(String[] args) {
		BiFunction<Integer, Integer, Integer> calculaMultiplicacao = (valor1, valor2) -> valor1 * valor2;
		System.out.println(calculaMultiplicacao.apply(2, 6));
	}

}